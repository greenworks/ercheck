module EnquiriesHelper
end
