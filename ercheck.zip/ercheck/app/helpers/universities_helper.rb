module UniversitiesHelper
end
