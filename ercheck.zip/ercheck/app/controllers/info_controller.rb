class InfoController < ApplicationController
  def home
  end

  def faq
  end

  def support
  end

  def contact
    @enquiry = Enquiry.new
  end

  def terms
  end

  def about
  end

  def search

  end

  def privacy

  end

  def advertise

  end

  def help

  end

  def career

  end

  def associate

  end

end
