class DepartmentsController < InheritedResources::Base
end
