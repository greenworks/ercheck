class FunctionsController < InheritedResources::Base
end
