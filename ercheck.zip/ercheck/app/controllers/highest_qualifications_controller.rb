class HighestQualificationsController < InheritedResources::Base
end
