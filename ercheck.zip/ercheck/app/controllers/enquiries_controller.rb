class EnquiriesController < InheritedResources::Base
end
