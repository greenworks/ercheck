class SettlementPendingSide < ActiveRecord::Base
  attr_accessible :name
end
