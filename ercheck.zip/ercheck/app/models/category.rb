class Category < ActiveRecord::Base
  attr_accessible :name, :description
end
