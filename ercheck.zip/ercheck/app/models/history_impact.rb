class HistoryImpact < ActiveRecord::Base
  attr_accessible :name
end
