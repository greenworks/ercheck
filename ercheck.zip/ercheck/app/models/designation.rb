class Designation < ActiveRecord::Base
  attr_accessible :description, :name
end
