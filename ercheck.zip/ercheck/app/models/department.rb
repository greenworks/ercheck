class Department < ActiveRecord::Base
  attr_accessible :description, :name
end
