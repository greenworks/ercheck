class Reason < ActiveRecord::Base
  attr_accessible :name
end
