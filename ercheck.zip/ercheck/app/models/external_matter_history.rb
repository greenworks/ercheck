class ExternalMatterHistory < ActiveRecord::Base
  attr_accessible :name
end
