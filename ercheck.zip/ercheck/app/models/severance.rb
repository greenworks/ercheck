class Severance < ActiveRecord::Base
  attr_accessible :name
end
