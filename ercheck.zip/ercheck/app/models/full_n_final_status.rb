class FullNFinalStatus < ActiveRecord::Base
  attr_accessible :name
end
