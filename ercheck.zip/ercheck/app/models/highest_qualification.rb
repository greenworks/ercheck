class HighestQualification < ActiveRecord::Base
  attr_accessible :description, :name
end
