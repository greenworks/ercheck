class TerminationDischargeReason < ActiveRecord::Base
  attr_accessible :name
end
