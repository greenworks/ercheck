class NoticePeriodServed < ActiveRecord::Base
  attr_accessible :name
end
