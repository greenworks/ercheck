class RehireFlag < ActiveRecord::Base
  attr_accessible :name
end
