//= require active_admin/base
$(document).ready(function() {
    $(".datepicker").datepicker( "option", "dateFormat", 'dd-mm-yy' );

});