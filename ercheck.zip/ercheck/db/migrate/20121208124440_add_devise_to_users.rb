class AddDeviseToUsers < ActiveRecord::Migration

end
