require 'test_helper'

class NoticePeriodPaidTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
