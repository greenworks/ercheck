require 'test_helper'

class SettlementPendingSideTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
