require 'test_helper'

class HighestQualificationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
