require 'test_helper'

class TerminationDischargeReasonTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
