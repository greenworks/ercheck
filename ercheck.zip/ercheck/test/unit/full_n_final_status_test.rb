require 'test_helper'

class FullNFinalStatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
