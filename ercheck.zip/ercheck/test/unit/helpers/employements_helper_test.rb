require 'test_helper'

class EmployementsHelperTest < ActionView::TestCase
end
