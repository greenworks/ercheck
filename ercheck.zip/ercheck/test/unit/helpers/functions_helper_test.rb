require 'test_helper'

class FunctionsHelperTest < ActionView::TestCase
end
