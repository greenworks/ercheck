require 'test_helper'

class DepartmentsHelperTest < ActionView::TestCase
end
