require 'test_helper'

class EmployersHelperTest < ActionView::TestCase
end
