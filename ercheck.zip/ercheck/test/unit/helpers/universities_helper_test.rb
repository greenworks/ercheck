require 'test_helper'

class UniversitiesHelperTest < ActionView::TestCase
end
