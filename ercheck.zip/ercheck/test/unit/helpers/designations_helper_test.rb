require 'test_helper'

class DesignationsHelperTest < ActionView::TestCase
end
