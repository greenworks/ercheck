require 'test_helper'

class HighestQualificationsHelperTest < ActionView::TestCase
end
