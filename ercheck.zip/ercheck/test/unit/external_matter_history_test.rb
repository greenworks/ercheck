require 'test_helper'

class ExternalMatterHistoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
