require 'test_helper'

class SeveranceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
