require 'test_helper'

class RehireFlagTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
