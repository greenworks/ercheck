# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Ercheck::Application.config.secret_token = '555a882ea6f356b8069e2b0a2f86b80a3a59fb1b341cc5956d67842ccaf18de8a3d68cd8182ab34105e9f00ccb9718a0a9a9946932f4aae3ef504668856971b0'
